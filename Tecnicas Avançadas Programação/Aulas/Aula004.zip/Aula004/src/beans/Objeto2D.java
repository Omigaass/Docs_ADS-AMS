/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author aluno
 */
public interface Objeto2D {
    public void moveX(double dX);
    public void moveY(double dY);
    public void moveXY(double dX, double dY);
}
